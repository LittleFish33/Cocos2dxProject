#pragma once
enum KEYCODESEND
{
	LEFT,RIGHT,UP,
	LEFTRELEASE, RIGHTRELEASE, UPRELEASE
};
struct SocketData
{
	int uid;
	KEYCODESEND codeSend;
	SocketData(int u, KEYCODESEND k) {
		uid = u;
		codeSend = k;
	}
};
